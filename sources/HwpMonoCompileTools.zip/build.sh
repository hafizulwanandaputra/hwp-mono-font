#!/bin/sh

echo -n "Insert jCmd value (empty if not need): "
read jCmd

run_build () {
    plan="$1"
    name="$2"

    cp "$plan" private-build-plans.toml

    if [ -z "$jCmd" ]; then
        npm run build -- contents::$name
    else
        npm run build -- contents::$name --jCmd="$jCmd"
    fi
}

run_build private-build-plans-hwp-sans-mono.toml        HwpSansMono
run_build private-build-plans-hwp-serif-mono.toml  HwpSerifMono
